# Mail App Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/Call_in/pen/wvwMxwX](https://codepen.io/Call_in/pen/wvwMxwX).

